import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-trip',
  standalone: true,
  imports: [],
  templateUrl: './edit-trip.component.html',
  styleUrl: './edit-trip.component.css'
})
export class EditTripComponent {

}
